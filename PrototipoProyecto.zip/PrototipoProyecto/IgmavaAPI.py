from flask import Flask, request
from flask_restful import Resource, Api
from sqlalchemy import create_engine
from json import dumps
from flask import jsonify
import random

db_connect = create_engine('mysql+pymysql://root:@127.0.0.1/igmava')
app = Flask(__name__)
api = Api(app)

class Usuarios(Resource):
    def get(self):
        conn = db_connect.connect() # connect to database
        query = conn.execute("select * from Users") # This line performs query and returns json result
        result = {'data': [dict(zip(tuple (query.keys()) ,i)) for i in query.cursor]}
        return jsonify(result)

    def post(self):
        data = request.json
        conn = db_connect.connect()
        query = conn.execute("insert into Users values ('{}', '{}', '{}', {}, '{}', '{}')".format(
                             data['nombre'],
                             data['RUT'],
                             data['procedencia'],
                             int(data['telefono']),
                             data['correo'],
                             data['contacto']))
        return 0

class Usuarios_rut(Resource):
    def get(self, rut):
        conn = db_connect.connect()
        query = conn.execute("select * from Users where rut='%s'" %rut)
        result = {'data': [dict(zip(tuple (query.keys()) ,i)) for i in query.cursor]}
        return jsonify(result)

    def delete(self, rut):
        conn = db_connect.connect()
        query = conn.execute("delete from Users where rut='%s'" %rut)
        return 0

    def put(self, rut):
        data = request.json
        conn = db_connect.connect()
        query = conn.execute("update Users set nombre='{}', procedencia='{}', telefono={}, correo='{}', contacto='{}' where rut='{}'".format(
                             data['nombre'],
                             data['procedencia'],
                             int(data['telefono']),
                             data['correo'],
                             data['contacto'],
                             rut))
        return 0
        
class Cabins(Resource):
    def get(self):
        conn = db_connect.connect() # connect to database
        query = conn.execute("select * from Cabins") # This line performs query and returns json result
        result = {'data': [dict(zip(tuple (query.keys()) ,i)) for i in query.cursor]}
        return jsonify(result)

class Cabins_id(Resource):
    def get(self, _id):
        conn = db_connect.connect()
        query = conn.execute("select * from Cabins where id=%d " %int(_id))
        result = {'data': [dict(zip(tuple (query.keys()) ,i)) for i in query.cursor]}
        return jsonify(result)
    
    def put(self, _id):
        data = request.json
        conn = db_connect.connect()
        query = conn.execute("update Cabins set Precio={}, Observaciones='{}'  where id={}".format(
                             data['precio'],
                             data['observaciones'],
                             int(_id)))
        return 0

class Reservas(Resource):
    def get(self):
        conn = db_connect.connect() # connect to database
        query = conn.execute("select * from Reservas") # This line performs query and returns json result
        result = {'data': [dict(zip(tuple (query.keys()) ,i)) for i in query.cursor]}
        return jsonify(result)

    def post(self):
        id_ = random.randint(0,1000000000) # Hay un problema en mysql y no funcionan indices con autoincremento
        data = request.json
        conn = db_connect.connect()
        query = conn.execute("insert into Reservas values ({}, '{}', '{}', '{}', {}, {}, {}, {}, {})".format(
			     id_,
                             data['RUT'],
                             data['in'],
                             data['out'],
                             int(data['costo']),
                             int(data['c1']),
                             int(data['c2']),
                             int(data['c3']),
                             int(data['pagado'])))
        return 0

class Reservas_id(Resource):
    def get(self, _id):
        conn = db_connect.connect()
        query = conn.execute("select * from Reservas where id=%d" %int(_id))
        result = {'data': [dict(zip(tuple (query.keys()) ,i)) for i in query.cursor]}
        return jsonify(result)

    def delete(self, _id):
        conn = db_connect.connect()
        query = conn.execute("delete from Reservas where id=%d" %int(_id))
        return 0

    def put(self, _id):
        data = request.json
        conn = db_connect.connect()
        query = conn.execute("update Reservas set rut='{}', check_in='{}', check_out='{}', costo={}, c1={}, c1={}, c3={}, pagado={} where id={}".format(
                             data['RUT'],
                             data['in'],
                             data['out'],
                             int(data['costo']),
                             int(data['c1']),
                             int(data['c2']),
                             int(data['c3']),
                             int(data['pagado']),
                             int(_id)))
        return 0

class Reservas_date(Resource):
    def get(self, date):
        conn = db_connect.connect()
        query = conn.execute("select * from Reservas where check_out >= '%s'" %date)
        result = {'data': [dict(zip(tuple (query.keys()) ,i)) for i in query.cursor]}
        return jsonify(result)

    def delete(self, date):
        conn = db_connect.connect()
        query = conn.execute("delete from Reservas where check_out < '%s'" %date)
        return 0

class Reservas_nopagadas(Resource):
    def get(self):
        conn = db_connect.connect()
        query = conn.execute("select * from Reservas where pagado=0")
        result = {'data': [dict(zip(tuple (query.keys()) ,i)) for i in query.cursor]}
        return jsonify(result)

class Disponible(Resource):
    def get(self, a, b):
        conn = db_connect.connect()
        query = conn.execute("select convert(sum(c1),char(1)) as c1, convert(sum(c2),char(1)) as c2, convert(sum(c3),char(1)) as c3 from Reservas where check_out > '{}' and check_in < '{}'".format(a,b))
        result = {'data': [dict(zip(tuple (query.keys()) ,i)) for i in query.cursor]}
        return jsonify(result)

api.add_resource(Usuarios, '/usuarios')
api.add_resource(Usuarios_rut, '/usuarios/<rut>') 
api.add_resource(Cabins, '/cabanas')
api.add_resource(Cabins_id, '/cabanas/<_id>') 
api.add_resource(Reservas, '/reservas')
api.add_resource(Reservas_id, '/reservas/<_id>') 
api.add_resource(Reservas_date, '/fecha/<date>') 
api.add_resource(Reservas_nopagadas, '/nopagado') 
api.add_resource(Disponible, '/disponible/<a>/<b>') 


if __name__ == '__main__':
     app.run(port='5003')
        
        
#Ejemplos para tests:
#curl 127.0.0.1:5003/usuarios
#curl 127.0.0.1:5003/usuarios/9345872
#curl -X POST -d '{"id":"4", "nombre":"Juan"}' -H "Content-Type: application/json" 127.0.0.1:5003/usuarios
#curl -X DELETE 127.0.0.1:5003/usuarios/1
#curl -X PUT -d '{"nombre":"Iris"}' -H "Content-Type: application/json" 127.0.0.1:5003/usuarios/1

#curl 127.0.0.1:5003/cabanas
#curl -X PUT -d '{"estado":1}' -H "Content-Type: application/json" 127.0.0.1:5003/cabanas/1

#curl 127.0.0.1:5003/reservas


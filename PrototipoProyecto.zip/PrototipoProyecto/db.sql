DROP DATABASE igmava;

CREATE DATABASE igmava;

USE igmava;

CREATE TABLE Users(
	Nombre VARCHAR(20) NOT NULL,
	RUT VARCHAR(20) NOT NULL,
	Procedencia VARCHAR(20),
	Telefono INT,
	Correo VARCHAR(20),
	Contacto VARCHAR(20)
);

CREATE TABLE Cabins(
	ID INT NOT NULL PRIMARY KEY,
	Precio INT NOT NULL,
	Observaciones VARCHAR(501)
);

CREATE TABLE Reservas(
	ID INT NOT NULL, 
	RUT VARCHAR(20) NOT NULL,
	Check_in DATE NOT NULL,
	Check_out DATE NOT NUll,
	Costo INT NOT NULL,
	C1 BOOLEAN,
	C2 BOOLEAN,
	C3 BOOLEAN,
	Pagado BOOLEAN
);

INSERT INTO Users
VALUES
('Juani Perez', '18345984-3', 'Santiago', 92384857, 'asd@gmai.com', 'directo'),
('Maria Gonzales', '13948237-4', 'Copiapo', 84472647, 'example@hotmail.com', 'Airbnb'),
('Alberto Medina', '9345872-k', 'La Serena', 83647183, 'ejemplo@uach.cl', 'diredcto');

INSERT INTO Cabins
VALUES
(1, 30, 'Una observacion muy importante'),
(2, 80, 'asd'),
(3, 25, '');

INSERT INTO Reservas
VALUES
(1, '18345984-3', '2020-06-10', '2020-06-15', '150', 1, 0, 0, 0),
(2, '13948237-4', '2020-06-14', '2020-06-15', 80, 0, 1, 0, 1),
(3, '9345872-k', '2020-06-16', '2020-06-20', 600, 1, 1, 0, 0);
